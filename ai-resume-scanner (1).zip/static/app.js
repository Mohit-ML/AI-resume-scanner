const dropArea = document.getElementById('dropArea');
const fileInput = document.getElementById('resumeFile');
const fileSelected = document.getElementById('fileSelected');
const scanForm = document.getElementById('scanForm');
const loader = document.getElementById('loader');
const results = document.getElementById('results');
const uploadZone = document.getElementById('uploadZone');
const scanBtn = document.getElementById('scanBtn');

// Drag & drop
['dragenter','dragover'].forEach(e => {
  dropArea.addEventListener(e, ev => { ev.preventDefault(); dropArea.classList.add('drag-over'); });
});
['dragleave','drop'].forEach(e => {
  dropArea.addEventListener(e, ev => { ev.preventDefault(); dropArea.classList.remove('drag-over'); });
});
dropArea.addEventListener('drop', e => {
  const file = e.dataTransfer.files[0];
  if (file && file.name.endsWith('.pdf')) setFile(file);
  else alert('Please drop a PDF file.');
});
dropArea.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => { if (fileInput.files[0]) setFile(fileInput.files[0]); });

function setFile(file) {
  const dt = new DataTransfer();
  dt.items.add(file);
  fileInput.files = dt.files;
  fileSelected.textContent = `✓ ${file.name} (${(file.size/1024).toFixed(1)} KB)`;
  fileSelected.classList.add('show');
}

scanForm.addEventListener('submit', async e => {
  e.preventDefault();
  if (!fileInput.files[0]) { alert('Please select a PDF file.'); return; }

  uploadZone.style.display = 'none';
  loader.classList.add('show');
  results.innerHTML = '';
  scanBtn.disabled = true;

  try {
    const fd = new FormData(scanForm);
    const res = await fetch('/analyze', { method: 'POST', body: fd });
    const data = await res.json();

    loader.classList.remove('show');
    uploadZone.style.display = '';
    scanBtn.disabled = false;

    if (!res.ok || !data.success) {
      results.innerHTML = `<div class="error-msg">⚠️ ${data.detail || 'Analysis failed. Please try again.'}</div>`;
      return;
    }
    renderResults(data);
  } catch (err) {
    loader.classList.remove('show');
    uploadZone.style.display = '';
    scanBtn.disabled = false;
    results.innerHTML = `<div class="error-msg">⚠️ Network error: ${err.message}</div>`;
  }
});

function renderResults(d) {
  const match = d.match;
  const hasJD = d.has_jd;
  const score = hasJD ? match.score : null;

  let scoreColor = '#8264ff';
  let badgeClass = 'badge-mid', badgeText = 'Moderate';
  if (score !== null) {
    if (score >= 70) { scoreColor = 'var(--accent3)'; badgeClass = 'badge-high'; badgeText = 'Strong Match'; }
    else if (score >= 40) { scoreColor = '#ffc850'; badgeClass = 'badge-mid'; badgeText = 'Partial Match'; }
    else { scoreColor = '#ff5050'; badgeClass = 'badge-low'; badgeText = 'Low Match'; }
  }

  const circumference = 2 * Math.PI * 54;
  const offset = score !== null ? circumference - (score / 100) * circumference : circumference;

  // Score card
  let scoreHTML = hasJD ? `
    <div class="score-card">
      <div class="score-ring-wrap">
        <svg class="score-ring" viewBox="0 0 120 120">
          <circle class="bg" cx="60" cy="60" r="54"/>
          <circle class="fill" cx="60" cy="60" r="54" id="scoreArc"
            style="stroke:${scoreColor}; stroke-dasharray:${circumference}; stroke-dashoffset:${circumference}"/>
        </svg>
        <div class="score-number">${score}%<span>Match</span></div>
      </div>
      <div class="score-info">
        <h2>Job Match Analysis</h2>
        <p>Compared against ${match.matched.length + match.missing.length} skills in the job description.</p>
        <div class="score-badge ${badgeClass}">${badgeText}</div>
      </div>
    </div>` : '';

  // Stats
  const totalSkills = d.total_skills;
  const cats = Object.keys(d.skills).length;
  const statsHTML = `
    <div class="stat-grid">
      <div class="stat-card">
        <div class="stat-label">Total Skills</div>
        <div class="stat-value">${totalSkills}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Categories</div>
        <div class="stat-value">${cats}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Experience</div>
        <div class="stat-value">${d.experience}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Word Count</div>
        <div class="stat-value">${d.word_count.toLocaleString()}</div>
      </div>
    </div>`;

  // Skills
  const catColors = { programming:'accent', web:'accent', backend:'accent', database:'accent', cloud:'accent', ml_ai:'accent', tools:'', soft:'' };
  let skillsHTML = '';
  for (const [cat, skills] of Object.entries(d.skills)) {
    const label = cat.replace('_',' ').replace(/\b\w/g, c=>c.toUpperCase());
    const cls = catColors[cat] || '';
    skillsHTML += `<div class="category-title">${label}</div>
      <div class="tags">${skills.map(s => `<span class="tag ${cls}">${s}</span>`).join('')}</div>`;
  }

  // Match panels
  let matchHTML = '';
  if (hasJD) {
    const matchedTags = match.matched.map(s => `<span class="tag matched">${s}</span>`).join('');
    const missingTags = match.missing.map(s => `<span class="tag missing">${s}</span>`).join('');
    
    let breakdownHTML = '';
    for (const [cat, bd] of Object.entries(match.breakdown)) {
      const label = cat.replace('_',' ').replace(/\b\w/g, c=>c.toUpperCase());
      breakdownHTML += `<div class="breakdown-row">
        <div class="breakdown-header">
          <span class="breakdown-label">${label}</span>
          <span class="breakdown-pct">${bd.matched}/${bd.total}</span>
        </div>
        <div class="bar-track"><div class="bar-fill" data-pct="${bd.pct}"></div></div>
      </div>`;
    }

    matchHTML = `
      <div class="two-col">
        ${matchedTags ? `<div class="panel">
          <div class="panel-title"><span class="panel-icon">✓</span> Matched Skills</div>
          <div class="tags">${matchedTags}</div>
        </div>` : ''}
        ${missingTags ? `<div class="panel">
          <div class="panel-title"><span class="panel-icon">✗</span> Missing Skills</div>
          <div class="tags">${missingTags}</div>
        </div>` : ''}
      </div>
      ${breakdownHTML ? `<div class="panel">
        <div class="panel-title"><span class="panel-icon">◉</span> Match by Category</div>
        ${breakdownHTML}
      </div>` : ''}`;
  }

  // Suggestions
  const suggestHTML = d.suggestions.map(s => `<div class="suggestion">${s}</div>`).join('');

  // Contact
  const contact = d.contact;
  const icons = { email:'@', phone:'☏', linkedin:'in', github:'⌥' };
  let contactItems = '';
  for (const [k,v] of Object.entries(contact)) {
    if (v) contactItems += `<div class="contact-item"><span class="contact-icon">${icons[k]}</span>${v}</div>`;
  }
  const contactHTML = contactItems ? `<div class="panel">
    <div class="panel-title"><span class="panel-icon">◐</span> Contact Info</div>
    ${contactItems}
    ${d.education.length ? `<div class="category-title" style="margin-top:16px">Education</div>
      <div class="tags">${d.education.map(e=>`<span class="tag">${e}</span>`).join('')}</div>` : ''}
  </div>` : '';

  results.innerHTML = scoreHTML + statsHTML +
    `<div class="two-col">
      <div class="panel">
        <div class="panel-title"><span class="panel-icon">◈</span> Skills Detected</div>
        ${skillsHTML || '<p style="color:var(--text-dim);font-size:0.85rem;">No skills detected.</p>'}
      </div>
      ${contactHTML}
    </div>` +
    matchHTML +
    (suggestHTML ? `<div class="panel">
      <div class="panel-title"><span class="panel-icon">◎</span> Suggestions</div>
      ${suggestHTML}
    </div>` : '');

  // Animate score arc
  if (hasJD && score !== null) {
    setTimeout(() => {
      const arc = document.getElementById('scoreArc');
      if (arc) arc.style.strokeDashoffset = offset;
    }, 100);
  }

  // Animate bars
  setTimeout(() => {
    document.querySelectorAll('.bar-fill[data-pct]').forEach(bar => {
      bar.style.width = bar.dataset.pct + '%';
    });
  }, 200);

  results.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
